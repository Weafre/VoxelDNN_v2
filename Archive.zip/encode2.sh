#!/bin/bash
Output_folder="Output/"
pc_level=10
depth=3
nocv=2000
par_level=(3 )
#Output_folder2="content/drive/MyDrive/ColabNotebooks/voxeldnnOutput/"
echo "What is signaling text?"
read signaling

#echo "What is signaling text for baseline?"
#read signaling2
echo "What is the command type? (voxel+hard threshold octree:1,training:2,sepamodel(DA,baseline 1,2,3 level):3, all octree: 4, voxel+ soft decision octree: 5, extended context(CE/CE+DA)) 6, soft octree mode on all block level: 7, pc statistic: 8, custom run: 9, decode: 10)"
read command_to_run


#all pc in folder TestPC
pcs=( "TestPC/MPEG_cat1_arco_vox10.ply"  "TestPC/PAULO_bumbameuboi_fr_points.ply"   "TestPC/PAULO_romanoillamp10_fr_points.ply"  "TestPC/MPEG_rednblack_vox10_1510.ply" "TestPC/Microsoft_phil10_vox10_0010.ply"  "TestPC/Microsoft_ricardo10_vox10_0011.ply"  "TestPC/MPEG_boxer_viewdep_vox10.ply"  "TestPC/MPEG_thaidancer_viewdep_vox10.ply"  "TestPC/MPEG_loot_vox10_1000.ply"   "TestPC/MPEG_cat1_shiva_00035_vox10.ply"    "TestPC/MPEG_cat1_frog_00067_vox10.ply"    )
pcs2=("TestPC/MPEG_boxer_viewdep_vox10.ply"  "TestPC/MPEG_thaidancer_viewdep_vox10.ply"  "TestPC/MPEG_loot_vox10_1000.ply"  "TestPC/MPEG_rednblack_vox10_1510.ply" )
models_dv=("Model/voxelDNN_4_128_dv/"  "Model/voxelDNN_4_64_dv/"  "Model/voxelDNN_4_32_dv/"  "Model/voxelDNN_4_16_dv/"  "../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/")
models=("Model/voxelDNN_4_128/"  "../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/"  "../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/")

case "$command_to_run" in
  #encoding using voxel dnn + octree
  "1")
    for pc in "${pcs[@]}";
    do
    python3  -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level $pc_level -ply "$pc" -depth $depth -output $Output_folder -model64 ${models[0]} -model32 ${models[1]}  -model16 ${models[2]} -model8 ${models[3]} -signaling $signaling -nocv $nocv
    done
  ;;
  "2")
  #python3 -m training.voxel_dnn_training -blocksize 64 -nfilters 64 -inputmodel Model/voxelDNN_4_64_dv/  -outputmodel Model/voxelDNN_4_64_dv/  -dataset ${dataset64_dv[0]}  -dataset ${dataset64_dv[1]} -dataset ${dataset64_dv[2]} -dataset ${dataset64_dv[3]} -dataset ${dataset64_dv[4]} -dataset ${dataset64_dv[5]} -dataset ${dataset64_dv[6]} -dataset ${dataset64_dv[7]} -dataset ${dataset64_dv[8]} -dataset ${dataset64_dv[9]} -dataset ${dataset64_dv[10]} -dataset ${dataset64_dv[11]} -dataset ${dataset64_dv[12]} -dataset ${dataset64_dv[13]}  -batch 8 -epochs 30 -portion_data 0.5

  #python3 -m training.voxel_dnn_training -blocksize 32 -nfilters 64 -inputmodel Model/voxelDNN_4_32_dv/  -outputmodel Model/voxelDNN_4_32_dv/  -dataset ${datasets32_dv[0]}  -dataset ${datasets32_dv[1]} -dataset ${datasets32_dv[2]} -dataset ${datasets32_dv[3]} -dataset ${datasets32_dv[4]} -dataset ${datasets32_dv[5]} -dataset ${datasets32_dv[6]} -dataset ${datasets32_dv[7]} -dataset ${datasets32_dv[8]} -dataset ${datasets32_dv[9]} -dataset ${datasets32_dv[10]}  -dataset ${datasets32_dv[11]} -dataset ${datasets32_dv[12]} -dataset ${datasets32_dv[13]} -dataset ${datasets32_dv[14]}   -batch 64 -epochs 10 -portion_data 0.5
  python3 -m training.voxel_dnn_training -blocksize 16 -nfilters 64 -inputmodel Model/voxelDNN_4_16_dv/  -outputmodel Model/voxelDNN_4_16_dv/  -dataset ${datasets16_dv[0]}  -dataset ${datasets16_dv[1]} -dataset ${datasets16_dv[2]} -dataset ${datasets16_dv[3]} -dataset ${datasets16_dv[4]} -dataset ${datasets16_dv[5]} -dataset ${datasets16_dv[6]}  -dataset ${datasets16_dv[7]} -dataset ${datasets16_dv[8]} -dataset ${datasets16_dv[9]} -dataset ${datasets16_dv[10]} -dataset ${datasets16_dv[11]}  -batch 128 -epochs 10 -portion_data 0.4

  python3 -m training.voxel_dnn_training -blocksize 128 -nfilters 64 -inputmodel Model/voxelDNN_4_128_dv/  -outputmodel Model/voxelDNN_4_128_dv/  -dataset ${dataset128_dv[0]}  -dataset ${dataset128_dv[1]} -dataset ${dataset128_dv[2]} -dataset ${dataset128_dv[3]} -dataset ${dataset128_dv[4]} -dataset ${dataset128_dv[5]} -dataset ${dataset128_dv[6]}  -dataset ${dataset128_dv[7]} -dataset ${dataset128_dv[8]} -dataset ${dataset128_dv[9]} -dataset ${dataset128_dv[10]} -dataset ${dataset128_dv[11]} -dataset ${dataset128_dv[12]} -dataset ${dataset128_dv[13]} -dataset ${dataset128_dv[14]} -batch 1 -epochs 10 -portion_data 0.5
  ;;
  "3")
#    #Baseline + DA
#    for pc in "${pcs[@]}";
#    do
#    python3  -m  voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level $pc_level -ply $pc -depth $depth -output $Output_folder -model64 ${models_dv[1]} -model32 ${models_dv[2]}  -model16 ${models_dv[3]} -model8 ${models_dv[4]} -signaling "${signaling}DA"
#    done
    #python3  -m  voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level $pc_level -ply pcs2 -depth 0 -output $Output_folder -model64 ${models[1]} -model32 ${models[2]}  -model16 ${models[3]} -model8 ${models[4]} -signaling $signaling

    #Baseline
    for dep in "${par_level[@]}";
    do
      for pc in "${pcs[@]}";
      do
      python3  -m  voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level $pc_level -ply $pc -depth $dep -output $Output_folder -model64 ${models[1]} -model32 ${models[2]}  -model16 ${models[3]} -model8 ${models[4]} -signaling $signaling
      done
    done
  ;;
  "4")
    for pc in "${pcs[@]}";
    do
    python3  -m  voxel_dnn_coder.all_octree_block_coding  -ply $pc -level $pc_level -output $Output_folder  -signaling $signaling
    done
  ;;
  "5")
    for pc in "${pcs[@]}";
    do
    python3  -m  voxel_dnn_coder.voxel_dnn_sp_soft_ot64  -ply $pc -level $pc_level -output $Output_folder  -signaling $signaling -model64 ${models[0]} -model32 ${models[1]}  -model16 ${models[2]} -model8 ${models[3]}
    done
  ;;
  "6")
  #Baseline + CE +DA
    for pc in "${pcs[@]}";
    do
    python3  -m  voxel_dnn_coder.voxel_dnn_extend_context2   -ply $pc -level $pc_level  -depth $depth -output $Output_folder  -signaling "${signaling}CEDA" -model128 ${models_dv[0]} -model64 ${models_dv[1]} -model32 ${models_dv[2]}  -model16 ${models_dv[3]} -model8 ${models_dv[4]}
    done
  #Baseline +CE
  for pc in "${pcs[@]}";
    do
    python3  -m  voxel_dnn_coder.voxel_dnn_extend_context2   -ply $pc -level $pc_level  -depth $depth -output $Output_folder  -signaling "${signaling}CE"  -model128 ${models[0]} -model64 ${models[1]} -model32 ${models[2]}  -model16 ${models[3]} -model8 ${models[4]}
    done

  ;;
  "7")
    for pc in "${pcs[@]}";
    do
    python3 -m voxel_dnn_coder.voxel_dnn_sp_soff_octree_all_level  -ply $pc -depth $depth -output $Output_folder  -signaling $signaling -model64 ${models[0]} -model32 ${models[1]}  -model16 ${models[2]} -model8 ${models[3]}
    done
  ;;
  "8")
    for pc in "${pcs[@]}";
    do
    python3 -m utils.pc_study -source $pc -level 5
    done
  ;;
  "9")
    for pc in "${pcs[@]}";
    do
    python3  -m  voxel_dnn_coder.voxel_dnn_extend_context2   -ply $pc -level $pc_level  -depth $depth -output $Output_folder  -signaling $singnaling -model128 ${models_dv[0]} -model64 ${models_dv[1]} -model32 ${models_dv[2]}  -model16 ${models_dv[3]} -model8 ${models_dv[4]}
    done
  ;;
  "10")
  for dep in "${par_level[@]}";
    do
      for pc in "${pcs2[@]}";
      do
      python3  -m  voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model_dec -level $pc_level -ply $pc -depth $dep -output $Output_folder -model64 ${models[1]} -model32 ${models[2]}  -model16 ${models[3]} -model8 ${models[4]} -signaling $signaling
      done
    done
  ;;
esac

pcs=("/datnguyen_dataset/database/MPEG/CTC/redandblack/Ply/redandblack_vox10_1510.ply" "/datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply" "/datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply" "/datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply" "/datnguyen_dataset/database/Test_Seq/Test_seq_cat1_vox12_vox10/Frog_00067_vox12_downsample_by2.ply" "/datnguyen_dataset/database/Test_Seq/Test_seq_cat1_vox12_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply" "/datnguyen_dataset/database/Test_Seq/Test_seq_cat1_vox12_vox10/Shiva_00035_vox12_downsample_by2.ply"  "/datnguyen_dataset/database/Microsoft/10bitdepth_full/phil10/ply/frame0010.ply"  "/datnguyen_dataset/database/Microsoft/10bitdepth_full/ricardo10/ply/frame0011.ply"  )

#some specific test
pcs2=("TestPC/PAULO_bumbameuboi_fr_points.ply"  "TestPC/PAULO_romanoillamp10_fr_points.ply" "TestPC/PAULO_bumbameuboi9.ply" "TestPC/PAULO_romanoillamp11.ply"  "TestPC/PAULO_bumbameuboi10.ply"  "TestPC/PAULO_romanoillamp10.ply"    )
#without cat 1
models=("../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/"  "../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/")

#with cat 1 in training dataset
models=("../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/"  "../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/")

models2=("Model/voxelDNN_4_64/"  "Model/voxelDNN_4_32/"  "../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/"  "../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/")


datasets16_dv=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6/"   "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct6/"         "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6/"    "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5_rt45/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6_rt45/"   "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct6_rt45/"         "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6_rt45/"      "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6_rt45_0.3n0.6rm/"   "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct6_rt45_0.3n0.6rm/"         "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6_rt45_0.3n0.6rm/")

datasets8=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct6/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct7/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct7/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct7/" )

#training dataset:
datasets32=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct5/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5/" )
datasets32_dv=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct5/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5/" "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4_0.3n0.6rm/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5_0.3n0.6rm/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct5_0.3n0.6rm/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4_rt45/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5_rt45/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct5_rt45/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5_rt45/" "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5_rt45_0.3n0.6rm/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct5_rt45_0.3n0.6rm/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5_rt45_0.3n0.6rm/" )

dataset64=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/" "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct4/"  "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4/" )

dataset64_dv=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/" "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct4/"  "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4/" "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3_0.3n0.6rm/" "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4_0.3n0.6rm/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct4_0.3n0.6rm/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3_rt45/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4_rt45/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct4_rt45/"     "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4_rt45/" "/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct4_rt45_0.3n0.6rm/"     "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4_rt45_0.3n0.6rm/"
)

#2000 pc from model net: /datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2/
#200 /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct2/
dataset128=("/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_3k/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3/"        "/datnguyen_dataset/database/MPEG/selected_8i_oct3/" )
dataset128_dv=("/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_10k/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct3/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_10k_0.3n0.6rm/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3_0.3n0.6rm/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct3_0.3n0.6rm/"
 "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3_rt45/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_3k_rt45/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3_rt45/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct3_rt45/"
  "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_3k_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3_rt45_0.3n0.6rm/"  "/datnguyen_dataset/database/MPEG/selected_8i_oct3_rt45_0.3n0.6rm/"
 )