
from glob import glob
from pyntcloud import PyntCloud
import numpy as np
import argparse
from utils.inout import occupancy_map_explore_test,normalize_from_mesh,normalize_pc,get_bin_stream_blocks
import open3d as o3d
# model net : /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512/*/train/*.ply
# /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/*/train/*.ply
# /datnguyen_dataset/database/MPEG/selected_8i_oct4/train/*ply
# /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/train/*.ply
def collect_statics(path):
    files=[]
    files += glob(path)
    bl64=[]
    spread=[]
    print('Pricessing ',len(files), ' files...')
    bl32=[]
    for file in files:
        pc = PyntCloud.from_file(file)
        coords = ['x', 'y', 'z']
        points = pc.points[coords]
        points=points.to_numpy()
        max_coord=np.max(points,axis=0)
        min_coord=np.min(points,axis=0)
        size=max_coord-min_coord+1
        acc_mul=1
        for i in range(size.shape[0]):
            if (size[i] == 0):
                size[i] = 1
            acc_mul*=size[i]
        if(acc_mul!=0):
           ocv=points.shape[0]
           bl64.append(ocv/acc_mul)
        else:
           print(file,max_coord,min_coord,len(pc.points[coords]))
        points = (points - 0.01) / 2
        points = np.abs(points)
        points = np.round(points)
        points = np.unique(points,axis=0)
        bl32.append(points.shape[0]/(acc_mul/8))
        spread.append(acc_mul/(64**3))
    print('ocv/bbox of block 32: %.06f' % (np.average(bl32) * 100))
    print('ocv/bbox of block 64: %.06f' % (np.average(bl64) * 100))
    print('bbox/volumne of block 64: %.06f' % (np.average(spread) * 100))
#ocv per block 64 and its downsampled block 32
def collect_statics_test_pc(path):
    boxes,_,_,coor_min_max,lower_level_ocv=occupancy_map_explore_test(path,10,4)
    rate32=[]
    rate64=[]
    spread=[]
    print('Point Cloud: ', path)
    print('Having ',boxes.shape[0], ' blocks' )
    for i in range(boxes.shape[0]):
        size=coor_min_max[i,3:] - coor_min_max[i,:3]
        acc_mul = 1
        for j in range(size.shape[0]):
            if (size[j] == 0):
                size[j] = 1
            acc_mul *= size[j]
        spread.append(acc_mul/(64**3))
        rate64.append(np.sum(boxes[i])/acc_mul)
        rate32.append(lower_level_ocv[i]/(acc_mul/8))
    print('ocv/bbox of block 32: %.06f' % (np.average(rate32) * 100))
    print('ocv/bbox of block 64: %.06f' % (np.average(rate64) * 100))
    print('bbox/volumne of block 64: %.06f' % (np.average(spread) * 100))

#ocv per block 64 and block 32 partitioned from the same pc
def collect_statics_test_pc_v2(path,bl_depth):
    block_size=int(2**bl_depth)
    boxes,_,_,coor_min_max,lower_level_ocv=occupancy_map_explore_test(path,10,10-bl_depth)
    spread=[]
    rate=[]
    print('Point Cloud: ', path)
    print('Having ',boxes.shape[0], ' blocks' )
    for i in range(boxes.shape[0]):
        size=coor_min_max[i,3:] - coor_min_max[i,:3]
        acc_mul = 1
        for j in range(size.shape[0]):
            if(size[j]==0):
                size[j]=1
            acc_mul *= size[j]
        rate.append(np.sum(boxes[i])/acc_mul)
        spread.append(acc_mul/(block_size**3))
    print('ocv/bbox of block %02d: %.06f' % (block_size, np.average(rate) * 100))
    print('bbox/volumne of block %02d: %.06f' % (block_size,np.average(spread) * 100))

def collect_statics_test_pc_v4(path,pc_level):
    block_size=int(2**6)
    _, blocks, _ = get_bin_stream_blocks(path, pc_level, pc_level-6)

    #boxes,_,_,coor_min_max,lower_level_ocv=occupancy_map_explore_test(path,pc_level,pc_level-6)
    rate=[]
    # print('Point Cloud: ', path)
    # print('Having ',len(blocks), ' blocks' )
    for i in range(len(blocks)):
        n_points=blocks[i].shape[0]
        rate.append((100*n_points)/(64**3))

    print('ocv/bbox of block ',  block_size, np.average(rate))
    return np.average(rate)
def collect_staticsss(path,pc_level):
    files = []
    files += glob(path)
    print('Pricessing ', len(files), ' files...')
    rate = []
    for file in files:
        dm=collect_statics_test_pc_v4(file,pc_level)
        rate.append(dm)
        #print(files,dm)
    #print('rho for dataset: ',np.average(rate))

def collect_statics_test_pc_v3(path,bl_depth):
    files=[]
    files += glob(path)
    print('Pricessing ',len(files), ' files...')
    spread=[]
    rate=[]
    for file in files:
        block_size=int(2**bl_depth)
        boxes,_,_,coor_min_max,lower_level_ocv=occupancy_map_explore_test(file,10,10-bl_depth)
        #spread=[]
        #rate=[]
        #print('Point Cloud: ', path)
        #print('Having ',boxes.shape[0], ' blocks' )
        for i in range(boxes.shape[0]):
            size=coor_min_max[i,3:] - coor_min_max[i,:3]
            acc_mul = 1
            for j in range(size.shape[0]):
                if(size[j]==0):
                    size[j]=1
                acc_mul *= size[j]
            rate.append(np.sum(boxes[i])/acc_mul)
            spread.append(acc_mul/(block_size**3))
    print('ocv/bbox of block %02d: %.06f' % (block_size, np.average(rate) * 100))
    print('bbox/volumne of block %02d: %.06f' % (block_size,np.average(spread) * 100))

def collect_statics_test_pc_v3(path,bl_depth):
    files=[]
    files += glob(path)
    print('Pricessing ',len(files), ' files...')
    spread=[]
    rate=[]
    for file in files:
        block_size=int(2**bl_depth)
        boxes,_,_,coor_min_max,lower_level_ocv=occupancy_map_explore_test(file,10,10-bl_depth)
        for i in range(boxes.shape[0]):
            size=coor_min_max[i,3:] - coor_min_max[i,:3]
            acc_mul = 1
            for j in range(size.shape[0]):
                if(size[j]==0):
                    size[j]=1
                acc_mul *= size[j]
            rate.append(np.sum(boxes[i])/acc_mul)
            spread.append(acc_mul/(block_size**3))
    print('ocv/bbox of block %02d: %.06f' % (block_size, np.average(rate) * 100))
    print('bbox/volumne of block %02d: %.06f' % (block_size,np.average(spread) * 100))

def knn_static(path):
    files=[]
    files+=glob(path)
    for path in files:
        pc=o3d.io.read_point_cloud(path)
        no_points=len(pc.points)
        print('Path to pc: ', path)
        print('File contains: ',no_points, ' points')
        distance=0
        for i in range(len(pc.points)):
            pcd_tree = o3d.geometry.KDTreeFlann(pc)
            [_, idx, _] = pcd_tree.search_knn_vector_3d(pc.points[i], 37)
            distance+= D_distance(np.asarray(pc.points)[idx[:]])
        print(distance/no_points)
def D_distance(points):
    anchor=points[0,:]
    sub=np.square(points-anchor)
    total=np.sum(sub,axis=1)
    root=np.sqrt(total)
    return np.average(root[1:])
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-source", '--source', type=str, help='path to input ply file')
    parser.add_argument("-dest", '--dest', type=str, help='path to output ply file')
    parser.add_argument("-level", '--level', type=int,default=1024,help='depth of output pc')
    args = parser.parse_args()
    #collect_statics(args.source)
    collect_statics_test_pc_v4(args.source,args.level)
    #collect_statics_test_pc_v2(args.source, args.level+1)
    #normalize_from_mesh(args.source, args.dest, args.level)
    #normalize_pc(args.source,args.dest,args.level)

    #collect_statics_test_pc(args.dest)
    #knn_static(args.source)
    #collect_staticsss(args.source,args.level)