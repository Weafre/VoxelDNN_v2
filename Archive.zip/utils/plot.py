import pickle
import numpy as np
from matplotlib import pyplot as plt
from glob import glob
from matplotlib import cm
from matplotlib.colors import Normalize
from scipy.interpolate import interpn
from utils.inout import pc_2_block
from pyntcloud import PyntCloud
import pandas as pd
import sys
import seaborn as sn
import pandas as pd
import matplotlib.pyplot as plt
def static_explore_4(files):
    print('Number of files being processed: ', len(files))
    print(files)
    voxelBlock = [[], [], [], []]
    octBlock = [[], [], [], []]
    ocv_bits=[]
    for path in files:
        f = open(path, 'rb')
        statics = pickle.load(f)
        for index in range(len(statics)):
            for level in range(4):
                if(len(statics[index][3][level])!=0):
                    voxelBlock[level]+=statics[index][3][level]
                if (len(statics[index][4][level]) != 0):
                    octBlock[level] += statics[index][4][level]
                ocv_bits.append([statics[index][0],statics[index][1]])

    octBlock=np.asarray(octBlock[1])
    print(octBlock.shape)
    print(np.average(octBlock[:,0]),np.average(octBlock[:,1]),np.sum(octBlock[:,1]), octBlock[np.argmin(octBlock[:,0]),1])
    ocv_bits=np.asarray(ocv_bits)
    print(np.sum(ocv_bits[ocv_bits[:,0]<6000,1])/np.sum(ocv_bits[:,1]))
    return np.asarray(ocv_bits)

def static_explore_5(files,target_level):
    #selecting ocv bits of a target block level
    print('Number of files being processed: ', len(files))
    print(files)
    voxelBlock = [[], [], [], []]

    for path in files:
        f = open(path, 'rb')
        statics = pickle.load(f)
        for index in range(len(statics)):
            for level in range(4):
                if(len(statics[index][3][level])!=0):
                    voxelBlock[level]+=statics[index][3][level]
            if(len(statics[index][3][1])==8):
                print('encoded as 8 block 32',statics[index])
    totalbits=0
    totalocv=0
    for i in range(4):
        try:
            bits_ocv=np.asarray(voxelBlock[i])
            curr_sum=np.sum(bits_ocv,axis=0)
            totalbits+=curr_sum[0]
            totalocv+=curr_sum[1]
            print(i,curr_sum)
        except:
            print('error: ',voxelBlock[i])
    print('total:',totalbits,totalocv)
    ocv_bits=voxelBlock[target_level]

    return np.asarray(ocv_bits)

def static_explore_baseline(path):
    #selecting ocv bits of a target block level
    # print('Number of files being processed: ', len(files))
    # print(files)
    voxelBlock = [[], [], [], []]
    block32=0
    #for path in files:
    f = open(path, 'rb')
    statics = pickle.load(f)

    for index in range(len(statics)):
        for level in range(4):
            if(len(statics[index][3][level])!=0):
                voxelBlock[level]+=statics[index][3][level]
            if (len(statics[index][3][1]) == 8):
                print('encoded as 8 block 32', statics[index])
                block32+=1
    print('number of block 64 encoded as 8 block 32: ', block32)
    totalbits=[]
    totalocv=[]
    for i in range(4):
        try:
            ocv_bits1=np.asarray(voxelBlock[i])
            curr_sum=np.sum(ocv_bits1,axis=0)
            totalbits.append(curr_sum[1])
            totalocv.append(curr_sum[0])
            print('Level: ',i,'ocv and bits: ',curr_sum, ' avg bpov: ', curr_sum[1]/curr_sum[0])
        except:
            print('error: ',voxelBlock[i])
    print('total:',100*(totalbits/np.sum(totalbits[:])),100*(totalocv/np.sum(totalocv[:])))

    ocv_bits=voxelBlock[1]

    return np.asarray(ocv_bits)

def static_explore_baseline_bitallocation(path):
    print(path)
    ocv_bits=[[],[],[],[]]
    ocv_bit64=[]
    encoded_levels=[]
    f = open(path, 'rb')
    statics = pickle.load(f)
    for index in range(len(statics)):
        currlv=0
        for level in range(4):
            if(len(statics[index][3][level])!=0):
                ocv_bits[level]+=statics[index][3][level]
                currlv=level
        encoded_levels.append(currlv)
        ocv_bit64.append([statics[index][0],statics[index][1]])
    ocv_bit64=np.asarray(ocv_bit64)
    encoded_levels=np.asarray(encoded_levels)
    ob=[]
    coords = []
    total_ocv=0
    for level in range(4):
        l=len(ocv_bits[level])
        level_ocv_bits=[]
        level_coords=[]
        for index in range(l):
            level_ocv_bits.append([ocv_bits[level][index][0],ocv_bits[level][index][1]])
            level_coords.append(ocv_bits[level][index][2])
        level_coords=np.asarray(level_coords)
        level_ocv_bits=np.asarray(level_ocv_bits)
        try:
            total_ocv+=np.sum(level_ocv_bits[:,0])
        except:
            print('zero block',level)
        print(level_ocv_bits.shape,level_coords.shape)
        ob.append(level_ocv_bits)
        coords.append(level_coords)
    for level in range(4):
        try:
            print(100*np.sum(ob[level][:,0])/total_ocv)
        except:
            print('no lbock')
    return encoded_levels,ocv_bit64,ob,coords

def static_explore_baseline_ocv(path):
    print(path)
    ocv_bits=[[],[],[],[]]
    ocv_bit64=[]
    f = open(path, 'rb')
    statics = pickle.load(f)
    for index in range(len(statics)):
        print(statics[index])
        return
        for level in range(4):
            if(len(statics[index][3][level])!=0):
                ocv_bits[level]+=statics[index][3][level]
        ocv_bit64.append([statics[index][0],statics[index][1]])
    ocv_bit64=np.asarray(ocv_bit64)
    ob=[]
    coords = []
    total_ocv=0
    for level in range(4):
        l=len(ocv_bits[level])
        level_ocv_bits=[]
        level_coords=[]
        for index in range(l):
            level_ocv_bits.append([ocv_bits[level][index][0],ocv_bits[level][index][1]])
            level_coords.append(ocv_bits[level][index][2])
        level_coords=np.asarray(level_coords)
        level_ocv_bits=np.asarray(level_ocv_bits)
        try:
            total_ocv+=np.sum(level_ocv_bits[:,0])
        except:
            print('zero block',level)
        print(level_ocv_bits.shape,level_coords.shape)
        ob.append(level_ocv_bits)
        coords.append(level_coords)
    for level in range(4):
        try:
            print(100*np.sum(ob[level][:,0])/total_ocv)
        except:
            print('no lbock')
    return ocv_bit64,ob,coords

def static_explore_extending_context(path):

    ocv_bits=[[],[],[],[]]
    ocv_bit64=[]
    f = open(path, 'rb')
    statics = pickle.load(f)
    for index in range(len(statics)):
        for level in range(4):
            if(len(statics[index][3][level])!=0):
                ocv_bits[level]+=statics[index][3][level]#contains ocv, bits, coordinate, border index
        ocv_bit64.append([statics[index][0],statics[index][1]])
    ocv_bit64=np.asarray(ocv_bit64)
    ob=[]
    coords = []
    extend_size=[]
    total_ocv=0
    for level in range(4):
        l=len(ocv_bits[level])
        level_ocv_bits=[]
        level_coords=[]
        level_extend_size=[]
        for index in range(l):
            level_ocv_bits.append([ocv_bits[level][index][0],ocv_bits[level][index][1]])
            level_coords.append(ocv_bits[level][index][2])
            level_extend_size.append(ocv_bits[level][index][3])
        level_coords=np.asarray(level_coords)
        level_ocv_bits=np.asarray(level_ocv_bits)
        level_extend_size = np.asarray(level_extend_size)
        try:
            total_ocv+=np.sum(level_ocv_bits[:,0])
        except:
            print(' ')

        ob.append(level_ocv_bits)
        coords.append(level_coords)
        extend_size.append(level_extend_size)
        index_count=[]
    for level in range(4):
        #print('\nLevel: ', level)
        level_ocv_bits=ob[level]
        level_extend_size=extend_size[level]
        level_coords=coords[level]
        try:
            max_idx = np.max(level_extend_size)
            ind_cnt = []
            for i in range(max_idx + 1):
                ind_cnt.append(np.count_nonzero(level_extend_size == i))
            index_count.append(ind_cnt)
            #print('Ocv percentage: ',100*np.sum(ob[level][:,0])/total_ocv)
            #print('Blocks in this level: ',level_ocv_bits.shape, level_coords.shape)
            #print('Border size index: ',ind_cnt,ind_cnt/np.sum(ind_cnt))
        except:
            index_count.append([])
            print('No block are encoded')
    return ocv_bit64,ob,coords,extend_size,index_count

def static_explore_0(files):
    #for multi resolution encoding method
    """
    structure of pkl file
    [ocv,op, flag_, curr_bits_cnt_voxel_dnn,curr_bits_cnt_octree]
    #ocv,bits
    """
    #separate model
    print('Number of files being processed: ', len(files))
    print(files)
    ocv_bits=[]
    for path in files:
        f = open(path, 'rb')
        statics = pickle.load(f)
        ocv_bits+=statics
    return np.asarray(ocv_bits)

def static_explore_1(files):
    #for multi resolution encoding method
    """
    structure
    [static9,static10]
    static9: [ocv,op,flag_,curr_bits_cnt]
    static10: [ocv, op]
    #ocv,bits
    """
    print('Number of files being processed: ', len(files))
    print(files)
    ocv_bits=[]
    for path in files:
        f = open(path, 'rb')
        statics = pickle.load(f)
        ocv_bits+=statics[1]
    ocv_bits=np.asarray(ocv_bits)
    return ocv_bits
def static_explore_2(files):
    #for multi resolution encoding method
    """
    structure
    [static9,static10]
    static9: [ocv,op,flag_,curr_bits_cnt]
    static10: [ocv, op]
    static10 has incorrect datashape
    #ocv,bits
    """
    print('Number of files being processed: ', len(files))
    print(files)
    ocv_bits=[]
    for path in files:
        f = open(path, 'rb')
        statics = pickle.load(f)
        ocv_bits+=statics[1]

    ob=[]
    for i in range(len(ocv_bits)):
        try:
            if (len(ocv_bits[i])==2):
                o=ocv_bits[i][0]
                b=ocv_bits[i][1]
                ob.append([o,b])
        except:
            print('Incorrect input shape: ',ocv_bits[i])
    ob=np.asarray(ob)
    print(ob.shape)
    return ob
def static_explore_3(files):
    #for multi resolution encoding method
    """
    structure of pkl file
    static.append([ocv,hm_flag,op,curr_bits_cnt])
    #[[584.0, [1], 1018, [[[1018, 584.0]], [], [], []]]]
    [1018, 584.0]: 1018 bits, 584 ocv
    """
    print('Number of files being processed: ', len(files))
    print(files)
    encoding_statistics = []
    block_counter = [[], [], [], []]
    ocv_bits=[]
    level_statistic = True
    for path in files:
        f = open(path, 'rb')
        heatmap = pickle.load(f)

        for index in range(len(heatmap)):
            # if(level_statistic==True):
            #     for level in range(4):
            #         if(len(heatmap[index][3][level])!=0):
            #             block_counter[level]+=heatmap[index][3][level]
            #counting empty+occupied block from flags
            #_,blk_cnt=compute_depth(heatmap[index][1],0,0,blk_cnt)
            ocv_bits.append([heatmap[index][0],heatmap[index][1]])

            #from encoding output folder
            #print(heatmap[index])
    #         bits_position=2
    #         bpov=heatmap[index][bits_position]/heatmap[index][0]
    #         if(bpov>bpov_max):
    #             max_bpov=heatmap[index]
    #             bpov_max=bpov
    #         if(bpov<bpov_min):
    #             min_bpov=heatmap[index]
    #             bpov_min=bpov
    #         ocv_bits.append([heatmap[index][0],heatmap[index][bits_position]])
    # print(max_bpov,min_bpov)


    # for path in files2:
    #     f = open(path, 'rb')
    #     heatmap = pickle.load(f)
    #     for index in range(len(heatmap)):
    #         ocv_bits.append([heatmap[index][0],heatmap[index][2]])

    #print out the Number of block, Avg bits, avg ocv, avg bpov for each block size
    # total_size=np.zeros(4)
    # if(level_statistic==True):
    #     for level in range(4):
    #         bl_size=int(64/(2**level))
    #         block_stat=np.asarray(block_counter[level])
    #         print('Number of block, Avg bits, avg ocv, avg bpov of block , total size', bl_size)
    #         print('%.2f, %.2f, %.2f, %.2f, %.2f\n'%(block_stat.shape[0],np.average(block_stat[:,0]),np.average(block_stat[:, 1]),np.average(block_stat[:,0])/np.average(block_stat[:, 1]),np.sum(block_stat[:,0])))
    #         total_size[level]=np.sum(block_stat[:,0])
    # print(total_size/np.sum(total_size))
    return np.asarray(ocv_bits)

def compute_depth(string, idx, depth, blk_cnt):
    if (string[idx] == 1):
        blk_cnt[depth]+=1
        return idx,blk_cnt
    elif (string[idx] == 2):
        idx += 1
        depth_ = depth + 1
        for i in range(8):
            if (string[idx] == 2):
                idx, blk_cnt = compute_depth(string, idx, depth_,blk_cnt)
            else:
                idx += 1
                blk_cnt[depth_]+=1
    return idx, blk_cnt

def density_scatter(ocv_bits):
    print(ocv_bits.shape)
    # x: array of ocv
    # y: array of bits
    x = ocv_bits[:,0]
    y = ocv_bits[:, 1]/ocv_bits[:, 0]

    ax=None
    bins = 20
    sort=True
    if ax is None:
        fig, ax = plt.subplots()
    data, x_e, y_e = np.histogram2d(x, y, bins=bins, density=True)
    z = interpn((0.5 * (x_e[1:] + x_e[:-1]), 0.5 * (y_e[1:] + y_e[:-1])), data, np.vstack([x, y]).T, method="splinef2d",
                bounds_error=False)

    # To be sure to plot all data
    z[np.where(np.isnan(z))] = 0.0
    z=z*10
    # Sort the points by density, so that the densest points are plotted last
    if sort:
        idx = z.argsort()
        x, y, z = x[idx], y[idx], z[idx]

    ax.scatter(x, y, c=z)

    norm = Normalize(vmin=np.min(z), vmax=np.max(z))
    cbar = fig.colorbar(cm.ScalarMappable(norm=norm), ax=ax)
    cbar.ax.set_ylabel('Density')
    plt.xlabel('Number of occupied voxels')
    plt.ylabel('bpov')
    plt.show()

    return ax
def quantization(ocv_bits,quantize_step):
    x1 = ocv_bits[:, 0]
    y1 = ocv_bits[:, 1] / ocv_bits[:, 0]
    indx = np.argsort(x1)
    x1 = x1[indx]
    y1 = y1[indx]
    avg_bpov1 = []
    last_idx1 = 0
    x_axis1 = []
    for ocv in np.arange(quantize_step, x1[-1], quantize_step):
        curr_idx = np.count_nonzero(x1 < ocv)
        if (curr_idx > last_idx1):
            avg_bpov1.append(np.average(y1[last_idx1:curr_idx]))
            last_idx1 = curr_idx
            x_axis1.append(ocv - quantize_step / 2)
    return x_axis1,avg_bpov1


def performance_onblock_multiline(ocv_bits,lg,colors,markers):


    plts=[]
    for i in range(len(ocv_bits)):
        ocv_bits1=ocv_bits[i]
        x_axis1,avg_bpov1=quantization(ocv_bits1,100)
        plts.append(plt.scatter(x_axis1, avg_bpov1, s=10,color=colors[i],marker=markers[i]))
    plt.ylabel('bpov', labelpad=15)
    plt.xlabel('Occupied voxels', labelpad=15)
    plt.legend(plts,lg, loc=0)
    plt.show()

def compute_cdf(ocv_bits):
    ocv2=ocv_bits[:,0]
    bits2=ocv_bits[:,1]
    ocv_bit2=list(zip(ocv2,bits2))
    sorted_ocv_bits2=sorted(ocv_bit2, key=lambda x: x[0])
    unzip_sorted_ocv_bits2= list(zip(*sorted_ocv_bits2))
    ocv2=np.asarray(unzip_sorted_ocv_bits2[0])
    bit2=np.asarray(unzip_sorted_ocv_bits2[1])
    filterd_ocv2=[]
    bits2=[]
    for i in range(len(ocv2)):
        if(filterd_ocv2==[] or filterd_ocv2[-1]!=ocv2[i]):
            filterd_ocv2.append(ocv2[i])
            bits2.append(bit2[i])
        elif(filterd_ocv2[-1]==ocv2[i]):
            bits2[-1]+=bit2[i]
    acc_bits2=[]
    total_bits2=np.sum(bits2)
    for i in range(len(bits2)):
        acc_bits2.append(np.sum(bits2[:i])/total_bits2)
    return filterd_ocv2,acc_bits2
def cdf_bits_over_ocv_multiline(ocv_bits,lg,colors):
    plts=[]
    for i in range(len(ocv_bits)):
        ocv_bits1 = ocv_bits[i]
        filterd_ocv, acc_bits=compute_cdf(ocv_bits1)
        plts.append(plt.plot(filterd_ocv, acc_bits,color=colors[i]))
    plt.legend(lg, loc=0)
    plt.xlabel('Occupied voxels')
    plt.ylabel('CDF of bits')
    plt.show()

def convert_to_rgb(minval, maxval, val, colors):
    EPSILON = sys.float_info.epsilon
    # "colors" is a series of RGB colors delineating a series of
    # adjacent linear color gradients between each pair.
    # Determine where the given value falls proportionality within
    # the range from minval->maxval and scale that fractional value
    # by the total number in the "colors" pallette.
    i_f = float(val-minval) / float(maxval-minval) * (len(colors)-1)
    # Determine the lower index of the pair of color indices this
    # value corresponds and its fractional distance between the lower
    # and the upper colors.
    i, f = int(i_f // 1), i_f % 1  # Split into whole & fractional parts.
    # Does it fall exactly on one of the color points?
    if f < EPSILON:
        return colors[i]
    else:  # Otherwise return a color within the range between them.
        (r1, g1, b1), (r2, g2, b2) = colors[i], colors[i+1]
        return int(r1 + f*(r2-r1)), int(g1 + f*(g2-g1)), int(b1 + f*(b2-b1))
def bitallocation_plot(ply, pkl, min_bpov, max_bpov):

    ocv_bit64,ocv_bits, coordinates = static_explore_baseline_ocv(pkl)
    #return
    pc = PyntCloud.from_file(ply)
    #print(pc.points.describe(), '\n', pc.points.dtypes)
    coords = ['x', 'y', 'z']
    # colors=pc.points[['red','green','blue']]
    points = pc.points[coords]
    points = points.to_numpy()
    #print('Coordinate of original point cloud', np.max(points, axis=0), np.min(points, axis=0))
    points_n_bits = np.zeros((points.shape[0], 6))
    points_n_bits[:, :3] = points[:, :3]
    colors_scale = [(0, 0, 255), (0, 255, 0), (255, 0, 0)]
    block_size=[64,32,16,8]
    points_n_bits[:, 3:]=1
    for level in range(len(ocv_bits)):
        level_ocv_bits=ocv_bits[level]
        level_coords=coordinates[level]
        try:
            bpov = level_ocv_bits[:, 1] / level_ocv_bits[:, 0]
        except:
            continue
        print('max, min, avg bpov: ', np.max(bpov), np.min(bpov), np.average(bpov))
        print('percentage of bpov in range: ',
              np.sum((bpov <= max_bpov) & (bpov >= min_bpov)) / level_ocv_bits.shape[0])

        bpov[bpov >= max_bpov] = max_bpov
        bpov[bpov <= min_bpov] = min_bpov
        # print('avg bpov: ', np.average(bpov))
        # min_bpov = np.min(bpov)
        # max_bpov = np.max(bpov)

        bls=block_size[level]

        for i in range(level_ocv_bits.shape[0]):
            a = ((points_n_bits[:, 0] - points_n_bits[:, 0] % bls) == level_coords[i][0]) * (
                    (points_n_bits[:, 1] - points_n_bits[:, 1] % bls) == level_coords[i][1]) * (
                        (points_n_bits[:, 2] - points_n_bits[:, 2] % bls) == level_coords[i][2])
            r, g, b = convert_to_rgb(min_bpov, max_bpov, bpov[i], colors_scale)
            points_n_bits[a, 3:] = [r, g, b]
            #points_n_bits[a, 3:] = [255,0,0]
    colors = points_n_bits[:, 3:]
    colors = colors.astype('uint8')
    d = {'x': points_n_bits[:, 0], 'y': points_n_bits[:, 1], 'z': points_n_bits[:, 2],
         'red': colors[:, 0], 'green': colors[:, 1], 'blue': colors[:, 2]}

    new_pc = PyntCloud(pd.DataFrame(data=d))
    #print(new_pc.points.describe(), '\n', pc.points.dtypes)
    new_pc.to_file(ply+'.bitalloc'+str(min_bpov)+'_'+str(max_bpov)+'.ply')


def variance(points):
    anchor = np.mean(points,axis=0)
    sub = np.square(points - anchor)
    try:
        avg = np.average(np.sum(sub, axis=1),axis=0)
    except:
        return 0
    #root = np.sqrt(total)
    return avg

def plot_with_variance(pkl,ply):
    _, child_blocks = pc_2_block(ply, 10, 4)
    encoded_level, ocv_bit64, _, _ = static_explore_baseline_bitallocation(pkl)
    #return
    pc = PyntCloud.from_file(ply)
    coords = ['x', 'y', 'z']
    points = pc.points[coords]
    points = points.to_numpy()
    var=[]
    bls = 64
    for index in range(len(child_blocks)):
        #child block: voxel child box, location
        coord_64=child_blocks[index][1]
        a = ((points[:, 0] - points[:, 0] % bls) == coord_64[0]) * (
                (points[:, 1] - points[:, 1] % bls) == coord_64[1]) * (
                    (points[:, 2] - points[:, 2] % bls) == coord_64[2])

        curr_points=points[a, :3]


        v=variance(curr_points)
        # print(v)

        #return
        # if(index>10):
        #     return
        var.append(v)
    var=np.asarray(var)
    print(np.mean(var))
    return encoded_level,ocv_bit64,var




def plot_selected_extend_block_size(indx_cnt):
    idx_cnt = np.zeros((5, 4))
    mapping={0:1,1:1,2:0,3:0}
    #print(indx_cnt)
    for i in range(4):
        curr_cnt=indx_cnt[3-i]
        #print(curr_cnt)
        if(len(curr_cnt)!=0):
            #print(idx_cnt[mapping[i]:mapping[i]+len(curr_cnt),i],curr_cnt[:])
            idx_cnt[mapping[i]:mapping[i]+len(curr_cnt),i]=curr_cnt[:]
    idx_cnt=np.asarray(idx_cnt,dtype=int)
    df_cm = pd.DataFrame(idx_cnt, index=[i for i in ['128', '64', '32', '16', '8']],
                         columns=[i for i in ['8', '16', '32', '64']])
    #mask = np.zeros_like(idx_cnt)
    #mask[idx_cnt == 0] = True


    plt.figure(figsize=(5, 4))
    sn.set(font_scale=1.3)#setting fonz scale
    #sn.heatmap(df_cm,mask=mask, annot=True,cmap="YlGnBu",fmt="d",linewidths=.5,linecolor='gray')
    sn.heatmap(df_cm,  annot=True, cmap="YlGnBu", fmt="d", linewidths=.5,annot_kws={'size':16})
    plt.xlabel('Actual block size', fontsize=16)
    plt.ylabel('Extending block size', fontsize=16)
    plt.axhline(y=5.0, xmin=0, xmax=1, color='black')
    plt.axvline(x=0, ymin=0, ymax=1, color='black')
    plt.axhline(y=0.0, xmin=0, xmax=1, color='black')
    plt.axvline(x=4, ymin=0, ymax=1, color='black')
    plt.xticks(fontsize=16)
    plt.yticks(fontsize=16)
    #YlGnBu
    plt.show()
def performance_plot(ocv_bits,names,markers,encoded_levels):
    colors=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    #index = ( 'Red and black', 'Arco Valentino','Bumbameuboi')
    df_list=[]
    for i in range(len(ocv_bits)):

        cnt=ocv_bits[i].shape[0]
        ocv=ocv_bits[i][:,0]
        bits=ocv_bits[i][:,1]
        bpov=bits/(ocv)

        ocv_bitsi=np.zeros((cnt,3))
        ocv_bitsi[:, 0] = 100*ocv/(64**3)
        print('rho: ',np.average(ocv_bitsi[:,0]))
        ocv_bitsi[:, 1] = bits
        ocv_bitsi[:, 2] = bpov

        #comment this if want to plot bits
        #quantized_ocv, quantized_bpov = quantization(ocv_bits[i], 50)
        # cnt = len(quantized_ocv)
        # ocv_bitsi = np.zeros((cnt, 3))
        # ocv_bitsi[:, 0] = quantized_ocv
        # ocv_bitsi[:, 2] = quantized_bpov


        df = pd.DataFrame(ocv_bitsi,columns=['Occupied Voxels','bits','bpov'])
        #df = pd.DataFrame(ocv_bitsi, columns=['Occupied Voxels', 'bits', 'bpov'])
        '$\rho'
        idx=np.zeros((cnt,1))
        idx+=i
        name = [names[int(j)] for j in idx]


        marker = [markers[int(j)] for j in encoded_levels[i]]
        df['Partitioning Level'] = marker

        color = [colors[int(j)] for j in idx]
        df['colors'] = color

        df['Point Cloud'] = name


        df_list.append(df)
    # concat_df=df_list[0]
    # for j in range(1,len(ocv_bits)):
    concat_df=pd.concat(df_list, ignore_index=True)
    minx=concat_df['Occupied Voxels'].min()
    maxx=concat_df['Occupied Voxels'].max()
    miny = concat_df['bits'].min()
    maxy = concat_df['bits'].max()
    print(concat_df,minx,maxx,miny,maxy)

    color = sn.color_palette('tab10')
    print(color.as_hex())
    plt.figure(figsize=(18, 6))
    #,xlim=(-20,maxx+20), ylim=(-20,maxy+20)
    g = sn.JointGrid(ratio=2, xlim=(-0.04, 6))
    #g = sn.JointGrid(ratio=2, xlim=(0, 15000))
    #g.ax_marg_y.set_axis_off()
    plt.delaxes(g.ax_marg_y)
    #plt.delaxes(g.ax_marg_x)
    # g=sn.jointplot(data=concat_df, x="Occupied Voxels", y="bits",hue="Point Cloud",palette='tab10')
    #
    # g.ax_joint.cla()
    # plt.sca(g.ax_joint)
    # plt.scatter(concat_df["Occupied Voxels"], concat_df["bits"],c=concat_df["colors"],s=concat_df["markers"])
    sn.scatterplot(data=concat_df,x="Occupied Voxels",y="bpov",hue="Point Cloud",ax=g.ax_joint,size='Partitioning Level',size_order=( '1 level','2 levels','4 levels', '3 levels' ), sizes=(5,50))
    sn.kdeplot(data=concat_df,x="Occupied Voxels",ax=g.ax_marg_x,hue='Point Cloud', linewidth=1.5,legend=False,common_norm=False)
    #axc=g.ax_marg_x.twinx()


    # sn.kdeplot(data=concat_df.loc[concat_df['Point Cloud'].isin(['Arco Valentino','Bumbameuboi'])],x="Occupied Voxels",ax=g.ax_marg_x,hue='colors', linewidth=1.5,legend=False, )
    # sn.kdeplot(data=concat_df.loc[concat_df['Point Cloud'].isin(['Phil','Loot'])], x="Occupied Voxels", ax=axc, hue='colors', linewidth=1.5, legend=False)
    # g.ax_marg_x.set_ylim((0,2))
    #sn.scatterplot(data=concat_df,x="Occupied Voxels", y="bpov",hue="Point Cloud",ax=g.ax_marg_y)
    #sn.scatterplot(data=concat_df, x="Occupied Voxels", y="bpov", hue="Point Cloud", ax=g.ax_joint,s=35)
    g.ax_joint.set_yscale('log')
    g.fig.get_axes()[0].legend(loc='best')
    #g.ax_marg_x.set_xlim(left=-150)
    # for i, row in enumerate(concat_df.values):
    #     g.ax_joint.plot(row[0], row[1], color=row[4], marker=row[3])
    #g.ax_joint.set_xscale('log')
    #g.ax_joint.set(xlabel=r'$\rho$', ylabel="bpov")

    g.ax_joint.set(xlabel='Percentage of occupied voxels', ylabel="bpov")
    plt.show()

def performance_plot_with_var(ocv_bits,names,markers,encoded_levels,var):
    colors=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    #index = ( 'Red and black', 'Arco Valentino','Bumbameuboi')
    df_list=[]
    for i in range(len(ocv_bits)):

        cnt=ocv_bits[i].shape[0]
        ocv=ocv_bits[i][:,0]
        bits=ocv_bits[i][:,1]
        bpov=bits/(ocv)
        vars=var[i]

        ocv_bitsi=np.zeros((cnt,3))
        ocv_bitsi[:, 0] = ocv
        ocv_bitsi[:, 1] = vars
        ocv_bitsi[:, 2] = bpov

        #comment this if want to plot bits
        #quantized_ocv, quantized_bpov = quantization(ocv_bits[i], 50)
        # cnt = len(quantized_ocv)
        # ocv_bitsi = np.zeros((cnt, 3))
        # ocv_bitsi[:, 0] = quantized_ocv
        # ocv_bitsi[:, 2] = quantized_bpov


        df = pd.DataFrame(ocv_bitsi,columns=['Occupied Voxels','vars','bpov'])
        idx=np.zeros((cnt,1))
        idx+=i
        name = [names[int(j)] for j in idx]


        marker = [markers[int(j)] for j in encoded_levels[i]]
        df['Partitioning Level'] = marker

        color = [colors[int(j)] for j in idx]
        df['colors'] = color

        df['Point Cloud'] = name


        df_list.append(df)
    concat_df=pd.concat(df_list, ignore_index=True)


    color = sn.color_palette('tab10')
    print(color.as_hex())
    plt.figure(figsize=(18, 6))
    #,xlim=(-20,maxx+20), ylim=(-20,maxy+20)
    g=sn.JointGrid(ratio=2 )
    #g.ax_marg_y.set_axis_off()
    plt.delaxes(g.ax_marg_y)
    #plt.delaxes(g.ax_marg_x)
    # g=sn.jointplot(data=concat_df, x="Occupied Voxels", y="bits",hue="Point Cloud",palette='tab10')
    #
    # g.ax_joint.cla()
    # plt.sca(g.ax_joint)
    # plt.scatter(concat_df["Occupied Voxels"], concat_df["bits"],c=concat_df["colors"],s=concat_df["markers"])
    sn.scatterplot(data=concat_df,x="vars",y="bpov",hue="Point Cloud",ax=g.ax_joint,size='Partitioning Level',size_order=( '1 level','2 levels','4 levels', '3 levels' ), sizes=(5,50))
    sn.kdeplot(data=concat_df,x="vars",ax=g.ax_marg_x,hue='Point Cloud', linewidth=1.5,legend=False)
    #sn.scatterplot(data=concat_df,x="Occupied Voxels", y="bpov",hue="Point Cloud",ax=g.ax_marg_y)
    #sn.scatterplot(data=concat_df, x="Occupied Voxels", y="bpov", hue="Point Cloud", ax=g.ax_joint,s=35)
    g.ax_joint.set_yscale('log')
    g.fig.get_axes()[0].legend(loc='best')
    g.ax_marg_x.set_xlim(left=-10)
    # for i, row in enumerate(concat_df.values):
    #     g.ax_joint.plot(row[0], row[1], color=row[4], marker=row[3])
    #g.ax_joint.set_xscale('log')
    plt.show()
def saving_patch():
    path = 'Output/PAULO_romanoillamp10_fr_points/baselinetCEDA/3levels.heatmap.pkl'
    ocv_bits = [[], [], [], []]
    ocv_bit64 = []
    f = open(path, 'rb')
    statics = pickle.load(f)
    found1 = False
    found2 = False
    for index in range(len(statics)):
        level = 1

        if ((len(statics[index][3][level]) != 0)):
            for j in range(len(statics[index][3][level])):
                if (statics[index][3][level][j][3] == 0):
                    ocv_bits[0].append(statics[index][3][level][j][0])
                    print('0: ', statics[index][3][level][j])

                if (statics[index][3][level][j][3] == 1):
                    ocv_bits[1].append(statics[index][3][level][j][0])
                    print('1: ', statics[index][3][level][j])
                if (statics[index][3][level][j][3] == 2):
                    ocv_bits[2].append(statics[index][3][level][j][0])
                    print('2: ', statics[index][3][level][j])
    #             # if (statics[index][3][level][j][3] == 2):
    #             #     print('2: ', statics[index][3][level][j])
    #             #     found2=True
    # print(np.average(ocv_bits[0]),np.average(ocv_bits[1]),np.average(ocv_bits[2]))
    pc = PyntCloud.from_file('TestPC/PAULO_romanoillamp10_fr_points.ply')
    points = pc.points
    print(points.head(), np.max(points))

    x = 640
    y = 64
    z = 384
    points2 = points.loc[
        (points['x'] >= x - 48) & (points['x'] <= x + 80) & (points['y'] >= y - 48) & (points['y'] <= y + 80) & (
                    points['z'] >= z - 48) & (points['z'] <= z + 80)]
    # print(points2.head(), np.max(points2))
    points2['red'] = 0
    points2['green'] = 0
    points2['blue'] = 0
    points2.loc[(points2['x'] >= x) & (points2['x'] <= x + 32) & (points2['y'] >= y) & (points2['y'] <= y + 32) & (
            points2['z'] >= z) & (points2['z'] <= z + 32), 'red'] = 255
    points2.loc[(points2['x'] >= x) & (points2['x'] <= x + 32) & (points2['y'] >= y) & (points2['y'] <= y + 32) & (
            points2['z'] >= z) & (points2['z'] <= z + 32), 'green'] = 0
    points2.loc[(points2['x'] >= x) & (points2['x'] <= x + 32) & (points2['y'] >= y) & (points2['y'] <= y + 32) & (
            points2['z'] >= z) & (points2['z'] <= z + 32), 'blue'] = 0
    print(points2.head(), np.max(points2))
    new_pc = PyntCloud(pd.DataFrame(data=points2))
    new_pc.to_file('TestPC/PAULO_romanoillamp10_fr_points_block32_0.ply')
    x = 576
    y = 320
    z = 416
    ext = 16
    points3 = points[(points['x'] >= x - ext) & (points['x'] <= x + 32 + ext) & (points['y'] >= y - ext) & (
                points['y'] <= y + 32 + ext) & (points['z'] >= z - ext) & (points['z'] <= z + 32 + ext)]
    points3['red'] = 0
    points3['green'] = 0
    points3['blue'] = 0
    points3.loc[(points3['x'] >= x) & (points3['x'] <= x + 32) & (points3['y'] >= y) & (points3['y'] <= y + 32) & (
            points3['z'] >= z) & (points3['z'] <= z + 32), 'red'] = 255
    points3.loc[(points3['x'] >= x) & (points3['x'] <= x + 32) & (points3['y'] >= y) & (points3['y'] <= y + 32) & (
            points3['z'] >= z) & (points3['z'] <= z + 32), 'green'] = 0
    points3.loc[(points3['x'] >= x) & (points3['x'] <= x + 32) & (points3['y'] >= y) & (points3['y'] <= y + 32) & (
            points3['z'] >= z) & (points3['z'] <= z + 32), 'blue'] = 0
    new_pc = PyntCloud(pd.DataFrame(data=points3))
    new_pc.to_file('TestPC/PAULO_romanoillamp10_fr_points_block32_1.ply')

if __name__ == '__main__':
    #lg=('Microsoft + MPEG 8i','MPEG 8i CAT1')
    #lg = ('baseline', 'all octree')
    lg = ('baseline', 'larger context')
    colors = ['#1f77b4', '#ff7f0e']
    markers = ['x', 'o']

    #files=[]
    #files += glob('Output/*Arco*/baseline/3levels.heatmap.pkl')
    #files += glob('Output/*Shiva*/baseline/3levels.heatmap.pkl')
    #files += glob('Output/loot*/extendcontext/3levels.heatmap.pkl')


    #files2 = []
    #files2 += glob('Output/*/extendcontext/3levels.heatmap.pkl')
    #files2 += glob('Output/*00035*vox12*/all_octree/.heatmap.pkl')
    #files2 += glob('Output/*frame0011*/baseline/3levels.heatmap.pkl')
    #files2 += glob('Output/*frame0011*/extendcontext/3levels.heatmap.pkl')
    #files2 += glob('Output/Microsoft*/baseline_4ds/3levels.heatmap.pkl')
    #ocv_bits2 = static_explore_baseline_bitallocation(files2)

    #idx=2
    #ocv_bits=[ocv_bits1,ocv_bits2]
    #cdf_bits_over_ocv_multiline(ocv_bits, lg[0:idx],colors[0:idx])
    #performance_onblock_multiline(ocv_bits,lg[0:idx],colors[0:idx],markers[0:idx])
    #density_scatter(ocv_bits1)
    #Output/Arco*/extendcontext/3levels.heatmap.pkl
    #'TestPC/MPEG_loot_vox10_1000.ply'
    # performance_onblock_multiline([ocv_bits1,],lg[0:1],colors[0:1],markers[0:1])
    # ply='TestPC/MPEG_loot_vox10_1000.ply'
    # #pkl='Output/loot_vox10_1000/extendcontext/3levels.heatmap.pkl'
    # pkl='Output/MPEG_rednblack_vox10_1510/extendct128/3levels.heatmap.pkl'
    # pkl='Output/MPEG_cat1_arco_vox10/baselinetCEDA/3levels.heatmap.pkl'
    # ply='TestPC/MPEG_cat1_arco_vox10.ply'
    #bitallocation_plot(ply,pkl, 1.0, 9.0)


    #cdf
    # path1='Output/MPEG_cat1_arco_vox10/baselinetCEDA/3levels.heatmap.pkl'
    # ocv_bit64, _, _ = static_explore_baseline_bitallocation(path1)
    #
    # path2 = 'Output/MPEG_rednblack_vox10_1510/baselinetCEDA/3levels.heatmap.pkl'
    # ocv_bit642, _, _ = static_explore_baseline_bitallocation(path2)
    # #
    # path3='Output/PAULO_bumbameuboi_fr_points/baselinetCEDA/3levels.heatmap.pkl'
    # ocv_bit643, _, _ = static_explore_baseline_bitallocation(path3)
    #
    # path4 = 'Output/Microsoft_phil10_vox10_0010/baselinetCEDA/3levels.heatmap.pkl'
    # ocv_bit644, _, _ = static_explore_baseline_bitallocation(path4)
    #
    # idx=4
    # lg = ('Phil', 'Red and black', 'Arco Valentino', 'Bumbameuboi' )
    # colors = ['#1f77b4', '#ff7f0e','#FF5733','#BD33FF']
    # markers = ['x', 'o', 'v', '+']
    # ocv_bits = [ocv_bit644, ocv_bit642,ocv_bit64,ocv_bit643]
    #ocv_bits = [ocv_bit642]
    #cdf_bits_over_ocv_multiline(ocv_bits, lg[0:idx], colors[0:idx])
    #performance_onblock_multiline(ocv_bits,lg[0:idx], colors[0:idx],markers[0:idx])

    #seaborn bit ocv plot
    #PAULO_romanoillamp10_fr_points

    files=[]
    files+=glob('Output/Microsoft_phil10_vox10_0010/baselinetCEDA/3levels.heatmap.pkl')
    files += glob('Output/MPEG_loot_vox10_1000/baselinetCEDA/3levels.heatmap.pkl')
    files += glob('Output/MPEG_cat1_arco_vox10/baselinetCEDA/3levels.heatmap.pkl')
    files += glob('Output/PAULO_bumbameuboi_fr_points/baselinetCEDA/3levels.heatmap.pkl')
    ocv_bits=[]
    encoded_levels=[]
    # # #names=['Phil', 'Thaidancer', 'Arco Valentino', 'Romanoillamp', 'Shiva', 'Frog', 'Ricardo', 'Boxer', 'Bumbameuboi', 'Redandblack', 'Loot']
    names = ['Phil','Loot', 'Arco Valentino', 'Bumbameuboi']
    markers = ['1 level', '2 levels', '3 levels', '4 levels']
    # #markers={'Phil':"x",'Loot':"o", 'Arco Valentino':"v", 'Romanoillamp':"+"}
    for path in files:
        # names.append(path[11:20])
        encoded_level, ocv_bit64, _, _ = static_explore_baseline_bitallocation(path)
        #ocv_bit64,_,encoded_level=static_explore_baseline_ocv(path)
        # print('Portion of encoded level:',100*np.count_nonzero(encoded_level==1)/encoded_level.shape[0])

        ocv_bits.append(ocv_bit64)
        encoded_levels.append(encoded_level)
        #for i in range(4):
            #print('Portion of encoded level:', 100 * np.count_nonzero(encoded_level == i) / encoded_level.shape[0])
        #     print('bpov per level :',i,': ', np.sum(ocv_bit64[encoded_level==i,1])/np.sum(ocv_bit64[encoded_level==i,0]))
        # print('bpov in threshold > ocv : ',
        #           np.sum(ocv_bit64[ ocv_bit64[:,0]>2000, 1]) / np.sum(ocv_bit64[ocv_bit64[:,0]>2000, 0]))
        # print('bpov in threshold < ocv : ',
        #       np.sum(ocv_bit64[ocv_bit64[:, 0] < 2000, 1]) / np.sum(ocv_bit64[ocv_bit64[:, 0] < 2000, 0]))

    performance_plot(ocv_bits,names,markers,encoded_levels)


    # # #extending size selection
    # files=[]
    # files+=glob('Output/Microsoft_phil10_vox10_0010/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/MPEG_loot_vox10_1000/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/MPEG_cat1_arco_vox10/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/PAULO_bumbameuboi_fr_points/baselinetCEDA/3levels.heatmap.pkl')
    # #files=glob('Output/*/baselinetCEDA/3levels.heatmap.pkl')
    # for path in files:
    #     print('Processing file: ', path)
    #     _, _, _, _,idx_cnt = static_explore_extending_context(path)
    #     plot_selected_extend_block_size(idx_cnt)

    #Occupied voxel in each block
    # files = []
    # files += glob('Output/*/baselinet/3levels.heatmap.pkl')
    # print(files)
    # ocv_bits = []
    # names=['Phil', 'Thaidancer', 'Arco Valentino', 'Romanoillamp', 'Shiva', 'Frog', 'Ricardo', 'Boxer', 'Bumbameuboi', 'Redandblack', 'Loot']
    # for path in files:
    #     ocv_bit = static_explore_baseline(path)
    #     ocv_bits.append(ocv_bit)

    #plotting extending size
    #saving_patch()


    #plot variance instead of density
    # files=[]
    # files+=glob('Output/Microsoft_phil10_vox10_0010/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/MPEG_loot_vox10_1000/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/MPEG_cat1_arco_vox10/baselinetCEDA/3levels.heatmap.pkl')
    # files += glob('Output/PAULO_bumbameuboi_fr_points/baselinetCEDA/3levels.heatmap.pkl')
    # files2=[]
    # files2 +=glob('TestPC/Microsoft_phil10_vox10_0010.ply')
    # files2 += glob('TestPC/MPEG_loot_vox10_1000.ply')
    # files2 += glob('TestPC/MPEG_cat1_arco_vox10.ply')
    # files2 += glob('TestPC/PAULO_bumbameuboi_fr_points.ply')
    # ocv_bits=[]
    # encoded_levels=[]
    # vars=[]
    # names = ['Phil','Loot', 'Arco Valentino', 'Bumbameuboi']
    # markers = ['1 level', '2 levels', '3 levels', '4 levels']
    # for i in range(len(files)):
    #     pkl=files[i]
    #     ply=files2[i]
    #     encoded_level, ocv_bit64, var = plot_with_variance(pkl,ply)
    #     ocv_bits.append(ocv_bit64)
    #     encoded_levels.append(encoded_level)
    #     vars.append(var)
    # performance_plot_with_var(ocv_bits,names,markers,encoded_levels,vars)



