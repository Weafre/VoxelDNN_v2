#!/bin/sh

#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/ricardo10/ply/frame0011.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Frog_00067_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC//Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct

#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes -signaling 4Models_w_superes


#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/phil10/ply/frame0010.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/ricardo10/ply/frame0011.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Frog_00067_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes

#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Egyptian_mask_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes

#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_pc1024/Frog_00067_vox12.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_pc1024/Arco_Valentino_Dense_vox12.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#
#python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply  -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 1000
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct

#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_pc1024/Frog_00067_vox12.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_pc1024/Arco_Valentino_Dense_vox12.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_wo_oct
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Egyptian_mask_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_superes
#
#python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/  -signaling 4Models_w_superes

#octree coding
#python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 2000
##superes + causal
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/phil10/ply/frame0010.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Frog_00067_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/ricardo10/ply/frame0011.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Egyptian_mask_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes/ -signaling mixedcontext
##finetune training
#python3 -m training.voxel_mixing_context -epoch 20 -blocksize 64 -outputmodel Model/voxelDnnSuperRes_finetuned/ -inputmodel Model/voxelDnnSuperRes -dataset /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/ -dataset /datnguyen_dataset/database/MPEG/selected_8i_oct4/  -dataset /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/  -dataset /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4/ -batch 4 -nfilters 64
##test on finetuned model
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/phil10/ply/frame0010.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft

#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Frog_00067_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Microsoft/10bitdepth_full/ricardo10/ply/frame0011.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft

#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/boxer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Egyptian_mask_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft
#
#python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft

#octree coding
#python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 3000
python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/redandblack/Ply/redandblack_vox10_1510.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelDnnSuperRes_finetuned/ -signaling mixedcontext_ft

python3 -m voxel_dnn_coder.voxel_dnn_super_res_causal  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/redandblack/Ply/redandblack_vox10_1510.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -superres Model/voxelSuperRes/ -signaling 4Models_w_superes

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 2000

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 1000

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 500

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/loot/Ply/loot_vox10_1000.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 200

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 2000

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 1000

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 500

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 9  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 200


python3 -m training.voxel_dnn_2contexts -epoch 50 -blocksize 64 -outputmodel Model/voxelDNN2context/ -inputmodel Model/voxelDNN2context -dataset /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/ -dataset /datnguyen_dataset/database/MPEG/selected_8i_oct4/  -dataset /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/  -batch 4 -nfilters 64

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/Test_Seq/mpeg_vox12_vox10/Thaidancer_viewdep_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_w_oct64 -nocv 2000

python3 -m voxel_dnn_coder.voxel_dnn_sp_ot64 -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_soft_oct64


python3  -m  voxel_dnn_coder.all_octree_block_coding  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 9 -output Output/  -signaling all_octree

python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model  -level 10  -ply /datnguyen_dataset/database/Microsoft/9bitdepth/ricardo9/ply/frame0100.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling baseline

python3 -m voxel_dnn_coder.voxel_dnn_extended_context  -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_cat1_vox12_vox10/Arco_Valentino_Dense_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling extendcontext



python3 -m voxel_dnn_coder.voxel_dnn_sp_soft_ot64 -level 10  -ply /datnguyen_dataset/database/Test_Seq/Test_seq_new_qt_vox10/Shiva_00035_vox12_downsample_by2.ply -depth 3 -output Output/ -model64 ../Lossless-PCC/Model/voxelDNN/voxelDNN_Mix_2/ -model32 ../Lossless-PCC/Model/voxelDNN32/MN_MP_MI/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling 4Models_soft_oct64

python3 -m voxel_dnn_coder.voxel_dnn_abac_multi_res_sepa_model  -level 10  -ply /datnguyen_dataset/database/MPEG/CTC/redandblack/Ply/redandblack_vox10_1510.ply -depth 3 -output Output/ -model64 Model/voxelDNN_CAT1/  -model32 .Model/voxelDNN_CAT132/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling sp_ft_cat1

python3 -m voxel_dnn_coder.voxel_dnn_extend_context2 -ply TestPC/MPEG_loot_vox10_1000.ply -level 10 -output Output/ -model128 Model/voxelDNN_4_128/ -model64 Model/voxelDNN_4_64/ -model32 Model/voxelDNN_4_32/ -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/ -signaling extendct128 -depth 3

python3 -m utils.ds_sampling_points /datnguyen_dataset/database/MPEG/selected_8i_1024_oct5 /datnguyen_dataset/database/MPEG/selected_8i_1024_oct5_0.3n0.6rm -portion 0.6

python3 -m voxel_dnn_coder.voxel_dnn_sp_soff_octree_all_level  -ply TestPC/MPEG_loot_vox10_1000.ply -level 10 -depth 3 -output Output/  -signaling test -model64 Model/voxelDNN_4_64_dv/ -model32 Model/voxelDNN_4_32_dv/  -model16 ../Lossless-PCC/Model/voxelDNN16/MN_MP_MI/ -model8 ../Lossless-PCC/Model/voxelDNN8/MN_MP_MI/

python3 -m utils.ds_rotation /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3/ /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct3_rt45/ --box 64

python3 -m utils.ds_rotation /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4/ /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct4_rt45/ --box 64
python3 -m utils.ds_rotation /datnguyen_dataset/database/MPEG/selected_8i_oct4/ /datnguyen_dataset/database/MPEG/selected_8i_oct4_rt45/ --box 64
python3 -m utils.ds_rotation /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4/ /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct4_rt45/ --box 64


python3 -m utils.ds_rotation /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4/ /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct4_rt45/ --box 32
 python3 -m utils.ds_rotation /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5/ /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct5_rt45/ --box 32
python3 -m utils.ds_rotation /datnguyen_dataset/database/MPEG/selected_8i_1024_oct5/ /datnguyen_dataset/database/MPEG/selected_8i_1024_oct5_rt45/ --box 32
python3 -m utils.ds_rotation /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5/ /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct5_rt45/ --box 32

python3 -m utils.ds_rotation /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3/ /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct3_rt45/ --box 128
python3 -m utils.ds_rotation /datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_3k/ /datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct2_3k_rt45/ --box 128
python3 -m utils.ds_rotation /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3/ /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct3_rt45/ --box 128
python3 -m utils.ds_rotation /datnguyen_dataset/database/MPEG/selected_8i_oct3/ /datnguyen_dataset/database/MPEG/selected_8i_oct3_rt45/ --box 128


python3 -m utils.ds_rotation /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5/ /datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5_rt45/ --box 16
 python3 -m utils.ds_rotation /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6/ /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6_rt45/ --box 16
python3 -m utils.ds_rotation /datnguyen_dataset/database/MPEG/selected_8i_1024_oct6/ /datnguyen_dataset/database/MPEG/selected_8i_1024_oct6_rt45/ --box 16
python3 -m utils.ds_rotation /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6/ /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6_rt45/ --box 16

python3 -m utils.ds_rotation /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct7/ /datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct7_rt45/ --box 8
python3 -m utils.ds_rotation /datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct6_3k/ /datnguyen_dataset/database/Modelnet40/ModelNet40_2000_pc512_oct6_3k_rt45/ --box 8
python3 -m utils.ds_rotation /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct7/ /datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct7_rt45/ --box 8
python3 -m utils.ds_rotation /datnguyen_dataset/database/MPEG/selected_8i_oct7/ /datnguyen_dataset/database/MPEG/selected_8i_oct7_rt45/ --box 8

datasets16=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct5/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct6/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct6/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct6/" )

datasets8=("/datnguyen_dataset/database/Modelnet40/ModelNet40_200_pc512_oct6/"  "/datnguyen_dataset/database/Microsoft/10bitdepth_selected_oct7/" "/datnguyen_dataset/database/MPEG/selected_8i_1024_oct7/" "/datnguyen_dataset/database/CAT1/cat1_selected_vox10_oct7/" )